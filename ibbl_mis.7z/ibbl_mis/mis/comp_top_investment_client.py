import wx
import xlrd
import os.path


class CompTopInvestmentClient:

    def create_gui(self):
        self.data_1 = {}
        self.data_2 = {}
        win = wx.Frame(None, title="Compare Top Investment Clients", size=(410, 335))
        bkg = wx.Panel(win)

        importButton = wx.Button(bkg, label="Extract")
        importButton.Bind(wx.EVT_BUTTON, self.print_name)

        delButton = wx.Button(bkg, label="Delete Files")
        delButton.Bind(wx.EVT_BUTTON, self.delete_files)

        self.filePickerCtrl_1 = wx.FilePickerCtrl(bkg, message="select", wildcard="*.xls")
        self.filePickerCtrl_2 = wx.FilePickerCtrl(bkg, message="Please select xl file", wildcard="*.xls")

        hbox = wx.BoxSizer()
        hbox.Add(self.filePickerCtrl_1, proportion=1, flag=wx.EXPAND, border=5)

        hbox1 = wx.BoxSizer()
        hbox1.Add(self.filePickerCtrl_2, proportion=1, flag=wx.EXPAND, border=5)

        hbox2 = wx.BoxSizer()
        hbox2.Add(importButton, proportion=0, flag=wx.LEFT, border=5)
        hbox2.Add(delButton, proportion=0, flag=wx.CENTER, border=5)

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(hbox, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)
        vbox.Add(hbox1, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)
        vbox.Add(hbox2, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)

        bkg.SetSizer(vbox)
        win.Show()

    def delete_files(self, event):
        #Delete the files used by the programs
        input_file1 = self.filePickerCtrl_1.GetPath()
        if not input_file1:
            return

        #Delete Text Files
        cur_dir = os.path.dirname(input_file1)
        cur_file_path = os.path.join(cur_dir, os.path.basename(input_file1)[:-4] + ".txt")
        os.remove(cur_file_path)

        input_file2 = self.filePickerCtrl_2.GetPath()
        if not input_file2:
            return

        cur_dir = os.path.dirname(input_file2)
        cur_file_path = os.path.join(cur_dir, os.path.basename(input_file2)[:-4] + ".txt")
        os.remove(cur_file_path)

        combined_file_path = os.path.join(cur_dir, "combined_data.txt")
        os.remove(combined_file_path)

        #Delete Excel Files
        os.remove(input_file1)
        os.remove(input_file2)

    def extract_data(self, sh, data, output_file):
        i = 0
        tmp_acc_no, tmp_name, tmp_total = "", "", 0
        try:
            while str(sh.cell(i, 1)).replace("text:u", "").replace("'", "").replace(" ", "") != "":
                if str(sh.cell(i, 1)).replace("text:u", "").replace("'", "").replace(" ", "").isdigit():
                    cust_id = str(sh.cell(i, 1)).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "")
                    name_col = str(sh.cell(i, 3)).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "")
                    if name_col.strip():
                        tmp_acc_no, tmp_name = cust_id, name_col

                if str(sh.cell(i, 2)).replace("text:u", "").replace("'", "").replace(" ", "") == "CUSTOMERTOTAL":
                    total_col = str(sh.cell(i, 6)).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "")
                    if total_col.strip():
                        tmp_total = total_col
                        data[tmp_acc_no] = [tmp_name.strip(), tmp_total.strip()]
                        output_file.write(str(tmp_acc_no) + "," + tmp_name.strip() + "," + total_col + "\n")
                i = i + 1
        except:
            pass

    def merge_data(self, data1, data2, combined_file):
        combined_data = {}

        for x in data1:
            if x in data2:
                combined_data[x] = [data1[x][0], data1[x][1], data2[x][0], data2[x][1]]
            elif x not in data2:
                #pass
                combined_data[x] = [data1[x][0], data1[x][1], '0', '0']

        for x in data2:
            if x not in data1:
                combined_data[x] = ['0', '0', data2[x][0], data2[x][1]]

        for i in combined_data:
            diff = float(combined_data[i][3]) - float(combined_data[i][1])
            diff = "%0.2f" % (diff/100000)
            combined_data[i] = [combined_data[i][0], combined_data[i][1], combined_data[i][2], combined_data[i][3], diff]

        sorted_combined_data = sorted(combined_data.items(), key=lambda x: float(x[1][4]), reverse=False)
        for i in range(len(sorted_combined_data)):
            combined_file.write(sorted_combined_data[i][0] + "," + sorted_combined_data[i][1][0] + "," + sorted_combined_data[i][1][1] + "," + sorted_combined_data[i][1][2] + "," + sorted_combined_data[i][1][3] + "," + sorted_combined_data[i][1][4] + "\n")

    def print_name(self, event):
        input_file1 = self.filePickerCtrl_1.GetPath()

        if not input_file1:
            return

        wb = xlrd.open_workbook(os.path.join(input_file1))
        wb.sheet_names()
        sh = wb.sheet_by_index(0)
        output_file1 = open(os.path.join(os.path.dirname(input_file1), os.path.basename(input_file1)[:-4] + ".txt"), "w")
        self.extract_data(sh, self.data_1, output_file1)

        input_file2 = self.filePickerCtrl_2.GetPath()

        if not input_file2:
            return

        wb = xlrd.open_workbook(os.path.join(input_file2))
        wb.sheet_names()
        sh = wb.sheet_by_index(0)
        output_file2 = open(os.path.join(os.path.dirname(input_file2), os.path.basename(input_file2)[:-4] + ".txt"), "w")

        self.extract_data(sh, self.data_2, output_file2)
        output_file3 = open(os.path.join(os.path.dirname(input_file2), "combined_data.txt"), "w")
        self.merge_data(self.data_1, self.data_2, output_file3)
        wx.MessageBox('Extract Completed', 'Info', wx.OK | wx.ICON_INFORMATION)