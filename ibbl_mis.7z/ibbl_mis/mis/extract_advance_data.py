import wx
import xlrd
import os.path

class ExtractAdvanceData:

    def create_gui(self):
        win = wx.Frame(None, title="Extract Advance Position Data ", size=(410, 335))
        bkg = wx.Panel(win)

        importButton = wx.Button(bkg, label="Extract")
        importButton.Bind(wx.EVT_BUTTON, self.print_name)
        self.filePickerCtrl_1 = wx.FilePickerCtrl(bkg, message="select", wildcard="*.xls")

        hbox = wx.BoxSizer()
        hbox.Add(self.filePickerCtrl_1, proportion=1, flag=wx.EXPAND, border=5)

        hbox2 = wx.BoxSizer()
        hbox2.Add(importButton, proportion=0, flag=wx.LEFT, border=5)

        vbox = wx.BoxSizer(wx.VERTICAL)
        vbox.Add(hbox, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)
        vbox.Add(hbox2, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)

        bkg.SetSizer(vbox)
        win.Show()


    def extract_data(self, sh, output_file):
        i = 197
        tmp_deposit_amt, tmp_invest_amt, tmp_overdue_amt = "", "", ""
        output_file.write("Deposit" + "," + "Investment" + "," + "Overdue" + "\n")
        try:
            while str(sh.cell(i, 1)).replace("text:u", "").replace("'", "").replace(" ", "") != "":
                br_name = str(sh.cell(i, 1)).replace("text:u", "").replace("'", "").replace(" ", "").replace(".", "").replace(",", "")
                br_name_list = ['BagerhatBr', 'BenapleBr', 'Chowgacha', 'Chuadanga', 'DakbanglaBr', 'DaulatpurBr', 'FultolaSME', 'JessoreBr', 'JhenaidahBr', 'Jhikorgacha', 'JibonNagar', 'KDAAvenue', 'KaligonjBr', 'KaligonjBr', 'Khulna', 'KolaroaBr', 'Kotchandpur', 'MaguraBr', 'MeherpurBr', 'MonglaBr', 'MoralgonjBr', 'NoaparaBr', 'NorailBr', 'Paikgacha', 'Sarankhola', 'SatkhiraBr', 'Shyamnagar']
                br_code_list = ['180', '164', '275', '230', '3', '182', '11', '125', '175', '160', '323', '316', '287', '186', '107', '169', '300', '246', '262', '150', '241', '135', '263', '232', '374', '143', '336']
                if br_name in br_name_list:
                    tmp_deposit_amt = str(sh.cell(i, 8)).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "").replace("number:", "")
                    tmp_invest_amt =  str(sh.cell(i, 11)).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "").replace("number:", "")
                    tmp_overdue_amt = (str(sh.cell(i, 19))).replace("empty:", "").replace("'", "").replace("text:u", "").replace(",", "").replace("number:", "")
                    #print("ee")
                    output_file.write(str(tmp_deposit_amt) + "," + str(tmp_invest_amt) + "," + str(tmp_overdue_amt)+ "\n")

                i = i + 1
        except Exception as e:
            print e
            pass


    def print_name(self, event):
        input_file1 = self.filePickerCtrl_1.GetPath()

        if not input_file1:
            exit()

        wb = xlrd.open_workbook(os.path.join(input_file1))
        wb.sheet_names()
        sh = wb.sheet_by_index(0)
        output_file1 = open(input_file1[input_file1.rfind("/") + 1:-4] + ".txt", "w")
        self.extract_data(sh, output_file1)

        wx.MessageBox('Extract Completed', 'Info', wx.OK | wx.ICON_INFORMATION)

if __name__ == '__main__':
    app = wx.App()
    test = ExtractAdvanceData()
    test.create_gui()
    app.MainLoop()
