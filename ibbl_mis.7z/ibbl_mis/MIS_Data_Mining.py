#!/usr/bin/env python

import wx
import mis.extract_advance_data as ead
import mis.extract_classified_daily
import mis.comp_top_investment_client
import mis.comp_class_client
import mis.comp_top_overdue_client


class MainFrame(wx.Frame):

    def __init__(self, parent, id):
        wx.Frame.__init__(self, parent, id, "MIS Data Process")
        menuBar = wx.MenuBar()
        menu1 = wx.Menu()

        menuItemDailyAdv = menu1.Append(wx.NewId(), "Daily &Advance Position")
        menuItemDailyClass = menu1.Append(wx.NewId(), "Daily &Classified Position")
        menuItemTopInvClient = menu1.Append(wx.NewId(), "Compare &Top Investment Clients")
        menuItemCompClassClient = menu1.Append(wx.NewId(), "Compare C&lassified Clients")
        menuItemTopOverdueClient = menu1.Append(wx.NewId(), "Compare Top O&verdue Clients")
        menuItemExit = menu1.Append(wx.NewId(), "&Exit")

        menuBar.Append(menu1, "&Daily Task")

        self.SetMenuBar(menuBar)
        self.Bind(wx.EVT_MENU, self.OnCloseMe, menuItemExit)
        self.Bind(wx.EVT_MENU, self.OpenDailyAdv, menuItemDailyAdv)
        self.Bind(wx.EVT_MENU, self.OpenDailyClass, menuItemDailyClass)
        self.Bind(wx.EVT_MENU, self.OpenTopInvClients, menuItemTopInvClient)
        self.Bind(wx.EVT_MENU, self.OpenCompClassClient, menuItemCompClassClient)
        self.Bind(wx.EVT_MENU, self.OpenCompTopOverdueClients, menuItemTopOverdueClient)

    def OnCloseMe(self, event):
        self.Close(True)

    def OpenDailyAdv(self, event):
        ExtAdvDat = ead.ExtractAdvanceData()
        ExtAdvDat.create_gui()

    def OpenDailyClass(self, event):
        ExtClassDaily = mis.extract_classified_daily.ExtractClassifiedDaily()
        ExtClassDaily.create_gui()

    def OpenTopInvClients(self, event):
        CompTopInvClient = mis.comp_top_investment_client.CompTopInvestmentClient()
        CompTopInvClient.create_gui()

    def OpenCompClassClient(self, event):
        CompClassClient = mis.comp_class_client.CompClassifiedClient()
        CompClassClient.create_gui()

    def OpenCompTopOverdueClients(self, event):
        CompTopOverdueClient = mis.comp_top_overdue_client.CompTopOverdueClient()
        CompTopOverdueClient.create_gui()


if __name__ == '__main__':
    app = wx.App()
    frame = MainFrame(None, -1)
    frame.Show()
    app.MainLoop()
