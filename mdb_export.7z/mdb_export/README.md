Export Microsoft Access Database to Mysql, sqlite in Linux and Windows.
I have created the project for exporting the MS Access Data to Mysql
of my previous client usings software made in VB for converting them
to PHP based solutions.
