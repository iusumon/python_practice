import wx
import db_conn
import TextCtrlAutoComplete as tcac
import wx.grid
from common import is_number
import os, sys
import subprocess


class EditPanel(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self, parent=parent)
        box = wx.StaticBox(self, wx.ID_ANY, "Details")

        self.editSizer = wx.GridBagSizer(hgap=7, vgap=7)

        self.lbl_id = wx.StaticText(self, label="ID")
        self.txt_id = wx.TextCtrl(self, value="", style=wx.TE_READONLY)
        self.editSizer.Add(self.lbl_id, pos=(0, 0))
        self.editSizer.Add(self.txt_id, pos=(0, 1))

        self.lbl_branch_name = wx.StaticText(self, label="Branch Name")
        self.txt_branch_name = wx.TextCtrl(self, value="")
        self.editSizer.Add(self.lbl_branch_name, pos=(1, 0))
        self.editSizer.Add(self.txt_branch_name, pos=(1, 1))

        self.lbl_designation = wx.StaticText(self, label="Designation of Manager")
        self.designation = tcac.ComboData().data_import("tbl_manager_desig", "manager_desig", "manager_desig")
        self.cbo_designation = tcac.TextCtrlAutoComplete(self, choices=self.designation.values(), size=(200, 30))
        self.editSizer.Add(self.lbl_designation, pos=(2, 0))
        self.editSizer.Add(self.cbo_designation, pos=(2, 1))

        self.lbl_district = wx.StaticText(self, label="District")
        self.district = tcac.ComboData().data_import("tbl_manager_desig", "district", "district")
        self.cbo_district = tcac.TextCtrlAutoComplete(self, choices=self.district.values(), size=(200, 30))
        self.editSizer.Add(self.lbl_district, pos=(3, 0))
        self.editSizer.Add(self.cbo_district, pos=(3, 1))

        self.SaveBtn = wx.Button(self, label="&Save")
        self.UpdateBtn = wx.Button(self, label="&Update")
        self.DeleteBtn = wx.Button(self, label="&Delete")
        self.ClearBtn = wx.Button(self, label="&Clear")
        self.ExitBtn = wx.Button(self, label="E&xit")

        self.SaveBtn.Bind(wx.EVT_BUTTON, self.SaveBtnClick)
        self.UpdateBtn.Bind(wx.EVT_BUTTON, self.UpdateButtonClick)
        self.DeleteBtn.Bind(wx.EVT_BUTTON, self.DeleteBtnClick)
        self.ClearBtn.Bind(wx.EVT_BUTTON, self.ClearBtnClick)
        self.ExitBtn.Bind(wx.EVT_BUTTON, self.ExitButtonClick)
        #
        self.txt_branch_name.Bind(wx.EVT_KILL_FOCUS, self.branch_name_KillFocus)
        # self.cbo_designation.Bind(wx.EVT_KILL_FOCUS, self.CboDesignationKillFocus)
        # self.cbo_district.Bind(wx.EVT_KILL_FOCUS, self.CboDistrictKillFocus)

        Sizer = wx.BoxSizer(wx.HORIZONTAL)
        Sizer.Add(self.SaveBtn, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)
        Sizer.Add(self.UpdateBtn, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)
        Sizer.Add(self.DeleteBtn, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)
        Sizer.Add(self.ClearBtn, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)
        Sizer.Add(self.ExitBtn, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)

        self.vbox = wx.StaticBoxSizer(box, wx.VERTICAL)
        self.vbox.Add(self.editSizer, proportion=0, flag=wx.EXPAND | wx.ALL, border=5)
        self.vbox.Add(Sizer, proportion=0, flag=wx.EXPAND | wx.ALL, border=10)

        self.SetSizerAndFit(self.vbox)
        self.txt_branch_name.SetFocus()

    # def CboDesignationKillFocus(self, event):
    #     if len(self.cbo_designation.Value) > 0:
    #         self.cbo_designation.SetValue(self.cbo_designation.Value.title())
    #
    # def CboDistrictKillFocus(self, event):
    #     if len(self.cbo_district.Value) > 0:
    #         self.cbo_district.SetValue(self.cbo_district.Value.title())
    #
    def branch_name_KillFocus(self, event):
        if len(self.txt_branch_name.Value) > 0:
            self.txt_branch_name.SetValue(self.txt_branch_name.Value.title())

    def ExitButtonClick(self, event):
        self.GetTopLevelParent().Close()

    def AutoGenID(self):
        conn = db_conn.Connection().connect()
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(id) AS max_id FROM tbl_manager_desig")

        last_id = 0
        exist = cursor.fetchone()
        if 'None' in str(exist):
            last_id = 0
        else:
            for row in exist:
                last_id = int(row)
        cur_id = int(last_id) + 1
        return cur_id

    def ValidateData(self):
        if not self.txt_branch_name.Value.strip():
            self.txt_branch_name.SetFocus()
            return "Branch Name is required"
        elif not self.cbo_designation.Value.strip():
            self.cbo_designation.SetFocus()
            return "Designation is required"
        elif not self.cbo_district.Value.strip():
            self.cbo_district.SetFocus()
            return "District is required"
        else:
            return "valid"

    def SaveBtnClick(self, event):
        valid_msg = self.ValidateData()

        #TODO: Use Python Database Library
        if valid_msg == "valid":
            try:
                conn = db_conn.Connection().connect()
                cursor = conn.cursor()
                next_id = self.AutoGenID()

                cursor.execute("INSERT INTO tbl_manager_desig\
                VALUES ('" + str(next_id) + "', '" + self.txt_branch_name.Value + "', '" + \
                self.cbo_designation.Value + "', '" + self.cbo_district.Value + "')" )
                dlg = wx.MessageBox("Increment Saved", "Successful", style=wx.ICON_INFORMATION|wx.STAY_ON_TOP|wx.OK)
                conn.commit()
                conn.close()
                self.grid = self.TopLevelParent.notebook.tabTwo.branchGrid
                self.grid.AppendRows(1)
                self.ClearField()
            except Exception as e:
                wx.MessageBox(e.message, "Error!")
        else:
            wx.MessageBox(valid_msg, "Information Missing!", style=wx.ICON_EXCLAMATION | wx.STAY_ON_TOP)

    def UpdateButtonClick(self, event):
        valid_msg = self.ValidateData()
        #TODO: Use Python Database Library
        if valid_msg == "valid":
            try:
                conn = db_conn.Connection().connect()
                cursor = conn.cursor()
                cursor.execute("UPDATE tbl_manager_desig SET branch_name = ?, manager_desig = ?, district = ? WHERE id = ?" , 
                               (self.txt_branch_name.Value, self.cbo_designation.Value, self.cbo_district.Value, self.txt_id.Value))
                dlg = wx.MessageBox("Successful", "Branch Profile Update", style=wx.ICON_INFORMATION|wx.STAY_ON_TOP|wx.OK)
                conn.commit()
                conn.close()
                self.ClearField()
            except Exception as e:
                wx.MessageBox(e.message, "Error!")
        else:
            wx.MessageBox(valid_msg, "Information Missing!",
                          style=wx.ICON_EXCLAMATION | wx.STAY_ON_TOP)

    def DeleteBtnClick(self, event):
        try:
            id = self.txt_id.Value
            conn = db_conn.Connection().connect()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM tbl_manager_desig WHERE id='" + str(id) + "'")
            conn.commit()
            conn.close()
            self.grid = self.TopLevelParent.notebook.tabTwo.branchGrid
            self.grid.DeleteRows(0, 1)
            self.ClearField()
            wx.MessageBox("Data Deleted")
        except IndexError:
            wx.MessageBox("You did not Select any row to Delete!")

    def ClearField(self):
        controls = self.editSizer.GetChildren()
        for ctrl in controls:
            widget = ctrl.GetWindow()
            if isinstance(widget, wx.TextCtrl):
                widget.Clear()
            elif isinstance(widget, wx.DatePickerCtrl):
                widget.SetValue(wx.DateTime_Now())
            elif isinstance(widget, wx.CheckBox):
                widget.SetValue(False)

        self.txt_branch_name.SetFocus()
        self.ViewPanel = self.TopLevelParent.notebook.tabTwo
        self.grid = self.TopLevelParent.notebook.tabTwo.branchGrid
        self.refreshData(self.grid)

        self.SaveBtn.Enable(True)
        self.UpdateBtn.Enable(False)
        # self.grid.DeleteRows()

    def ClearBtnClick(self, event):
        self.grid = self.TopLevelParent.notebook.tabTwo.branchGrid
        self.ClearField()

    def refreshData(self, branchGrid):
        #in EditPanel
        conn = db_conn.Connection().connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM tbl_manager_desig"
        cursor.execute(sql)
        rows = cursor.fetchall()
        if branchGrid.GetNumberRows() > 0:
            branchGrid.DeleteRows(0, branchGrid.GetNumberRows())
        if len(rows) > 0:
            branchGrid.AppendRows(len(rows))
            for i in range(0, len(rows)):
                for j in range(0, 4):
                    cell = rows[i]
                    branchGrid.SetCellValue(i, j, str(cell[j]))
                    # if j == 5 or j== 7:
                    #     branchGrid.SetCellAlignment(i, j, wx.ALIGN_RIGHT, wx.ALIGN_CENTER)
        conn.close()


class ViewPanel(wx.Panel):

    def __init__(self, parent):
        wx.Panel.__init__(self, parent, id=wx.ID_ANY)
        self.branchGrid = wx.grid.Grid(self, -1, size=(700, 327))
        self.BtnLoad = wx.Button(self, label="Load")
        r = self.CountRow()
        self.branchGrid.CreateGrid(r, 4)

        self.resizeGridColumn()
        self.refreshData()
        sizer = wx.BoxSizer(wx.VERTICAL)
        btnSizer = wx.BoxSizer(wx.HORIZONTAL)
        sizer.Add(self.branchGrid, proportion=0, flag=wx.EXPAND|wx.ALL, border=10)
        btnSizer.Add(self.BtnLoad, 0, wx.ALIGN_CENTER | wx.BOTTOM, 5)
        sizer.Add(btnSizer)
        self.SetSizerAndFit(sizer)

        self.BtnLoad.Bind(wx.EVT_BUTTON, self.branchGridClick)

    def branchGridClick(self, event):
        try:
            self.row_index = self.branchGrid.GetSelectedRows()[0]
            cell_value=[]
            for i in range(0, 4):
                cell_value.append(self.branchGrid.GetCellValue(self.row_index, i))
            self.EditPanel = self.TopLevelParent.notebook.tabOne
            self.EditPanel.txt_id.Value = str(cell_value[0])
            self.EditPanel.txt_branch_name.Value = str(cell_value[1])
            self.EditPanel.cbo_designation.Value = str(cell_value[2])
            self.EditPanel.cbo_designation._showDropDown(False)
            self.EditPanel.cbo_district.Value = str(cell_value[3])
            self.EditPanel.cbo_district._showDropDown(False)

            self.EditPanel.SaveBtn.Enabled=False
            self.EditPanel.UpdateBtn.Enabled=True
            event.Skip()
            self.TopLevelParent.notebook.SetSelection(0)
            self.EditPanel.txt_branch_name.SetFocus()
        except IndexError:
            wx.MessageBox("You did not select any row to load")

    def refreshData(self):
        #In ViewPanel
        conn = db_conn.Connection().connect()
        cursor = conn.cursor()
        sql = "SELECT * FROM tbl_manager_desig"
        cursor.execute(sql)
        rows = cursor.fetchall()
        if self.branchGrid.GetNumberRows() > 0:
            self.branchGrid.DeleteRows(0, self.branchGrid.GetNumberRows())
        if len(rows) > 0:
            self.branchGrid.AppendRows(len(rows))
            for i in range(0, len(rows)):
                for j in range(0, 4):
                    cell = rows[i]
                    self.branchGrid.SetCellValue(i, j, str(cell[j]))
                    # if j == 5 or j== 7:
                    #     self.branchGrid.SetCellAlignment(i, j, wx.ALIGN_RIGHT, wx.ALIGN_CENTER)
        conn.close()
        # self.branchGrid.SetColMinimalAcceptableWidth(0)
        # self.branchGrid.SetColSize(0, 0)
        # self.branchGrid.SetColSize(5, 0)
        # self.branchGrid.SetColSize(7, 0)
        # self.branchGrid.SetColSize(8, 0)

    def resizeGridColumn(self):
        self.branchGrid.SetColLabelValue(0, ("ID"))
        self.branchGrid.SetColSize(0, 30)
        self.branchGrid.SetColLabelValue(1, ("Branch Name"))
        self.branchGrid.SetColSize(1, 170)
        self.branchGrid.SetColLabelValue(2, ("Designation"))
        self.branchGrid.SetColSize(2, 170)
        self.branchGrid.SetColLabelValue(3, ("District"))
        self.branchGrid.SetColSize(3, 70)

    def CountRow(self):
        conn = db_conn.Connection().connect()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM tbl_manager_desig")
        rows = cursor.fetchall()
        i = 0
        for r in rows:
            i += 1
        return i
        conn.close()


class NoteBookIncrement(wx.Notebook):
    def __init__(self, parent):
        wx.Notebook.__init__(self, parent, id=wx.ID_ANY, style=wx.BK_TOP, size=(570, 400))
        
        self.sizer = wx.BoxSizer(wx.VERTICAL)

        self.tabOne = EditPanel(self)
        self.AddPage(self.tabOne, "Enter Data")
        self.sizer.Add(self.tabOne)

        self.tabTwo = ViewPanel(self)
        self.AddPage(self.tabTwo, "View Profile")
        self.sizer.Add(self.tabTwo)

        self.SetSizer(self.sizer)


class BranchProfile(wx.Frame):
    def __init__(self, parent, pid):
        wx.Frame.__init__(self, parent, pid, "Branch Profile")
        self.notebook = NoteBookIncrement(self)
        self.sizer = wx.BoxSizer(wx.VERTICAL)
        self.sizer.Add(self.notebook)
        self.SetSizerAndFit(self.sizer)
        self.Show()
        self.CenterOnScreen()


if __name__ == '__main__':
    app = wx.App()
    new = BranchProfile(None, -1)
    app.MainLoop()
